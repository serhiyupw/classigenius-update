import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class PostService {

  private url = 'http://jsonplaceholder.typicode.com/posts';
  constructor(private http: HttpClient) { }


  getPosts() {
    return this.http.get(this.url);
  }

  createPost(post) {
    return this.http.post(this.url, JSON.stringify(post));

  }

  updatePost(post) {

    return this.http.patch(this.url + '/' + post.id, JSON.stringify({ isRead: true }));
  }

  // deletePost(post) {
  //   return this.http.delete(this.url + '/' + post.id).pipe(
  //     catchError((error: Response) => {
  //       if (error.status === 404) {
  //         return throwError(new err);
  //       }
  //       return throwError(new AppError(error));
  //     }
  //     )
  //   );
  // }

  deletePost(id) {
    return this.http.delete(this.url + '/' + id);
  }

}

