import { TestBed } from '@angular/core/testing';

import { FsesiteService } from './fsesite.service';

describe('FsesiteService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FsesiteService = TestBed.get(FsesiteService);
    expect(service).toBeTruthy();
  });
});
