import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CompileShallowModuleMetadata } from '@angular/compiler';
// import { iSegment } from '../segments/iSegment';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { BadInput } from '../_common/bad-input';
import { NotFoundError } from '../_common/not-found-error';
import { AppError } from '../_common/app-error';
import { DataService } from './data.service';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class SegmentService extends DataService {
  constructor(http: HttpClient) {
    super('http://80.241.219.201:8080/InvoiceCloudServer/Api/segment', http);
  }
}


// @Injectable({
//   providedIn: 'root'
// })
// export class SegmentService {

//   private baseUrl = 'http://80.241.219.201:8080/InvoiceCloudServer/Api/segment';
//   constructor(private http: HttpClient) {
//   }

// // getSegments() {
//   //   return this.http.get<iSegment[]>(`${this.baseUrl}/read.php`);
//   // }

//   getAll() {
//     return this.http.get(`${this.baseUrl}/read.php`)
//     .pipe(map(response => response,catchError(this.handleError)));
//   }

//   // getSegment(segmentid) {
//   //   let url = `${this.baseUrl}/read_single.php/${segmentid}`;
//   //   let obj = { "id": segmentid };
//   //   return this.http.post<iSegment>(url, JSON.stringify(obj));
//   // }

//   get(id) { 
//     let obj = { "id": id };
//     return this.http.post(`${this.baseUrl}/read_single.php/${id}`,JSON.stringify(obj))
//     .pipe(map(response => response,catchError(this.handleError)));
//   }

//   // updateSegment(segment) {
//   //   let url = `${this.baseUrl}/update.php`;
//   //   return this.http.post(url, JSON.stringify(segment));
//   // }
//   update(object) {
//    // let url = `${this.baseUrl}/update.php`;
//     return this.http.post(`${this.baseUrl}/update.php`, JSON.stringify(object))
//     .pipe(map(response => response,catchError(this.handleError)));
//   }

//   // deleteSegment(id) {
//   //   let url = `${this.baseUrl}/delete.php`;
//   //   let obj = { "segmentid": id };
//   //   return this.http.post(url, JSON.stringify(obj));
//   // }

//   delete(id) {
//     // let url = `${this.baseUrl}/update.php`;
//      return this.http.post(`${this.baseUrl}/delete.php`, JSON.stringify({ "id": id }))
//      .pipe(map(response => response,catchError(this.handleError)));
//    }

//   // createSegment(segment) {
//   //   let url = `${this.baseUrl}/create.php`;
//   //   return this.http.post(url, JSON.stringify(segment));
//   // }

//   create(object) {
//      return this.http.post(`${this.baseUrl}/create.php`, JSON.stringify(object))
//      .pipe(map(response => response,catchError(this.handleError)));
//    }


//   private handleError(error: Response) {
//     if (error.status === 400)
//       return Observable.throw(new BadInput(error.json()));

//     if (error.status === 404)
//       return Observable.throw(new NotFoundError());

//     return Observable.throw(new AppError(error));
//   }

// }

