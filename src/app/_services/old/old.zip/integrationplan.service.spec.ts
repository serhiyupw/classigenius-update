import { TestBed } from '@angular/core/testing';

import { IntegrationplanService } from './integrationplan.service';

describe('IntegrationplanService', () => {
  let service: IntegrationplanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IntegrationplanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
