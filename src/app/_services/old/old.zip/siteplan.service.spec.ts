import { TestBed } from '@angular/core/testing';

import { SiteplanService } from './siteplan.service';

describe('SiteplanService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SiteplanService = TestBed.get(SiteplanService);
    expect(service).toBeTruthy();
  });
});
