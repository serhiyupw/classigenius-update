import { TestBed } from '@angular/core/testing';

import { ClientplanService } from './clientplan.service';

describe('ClientplanService', () => {
  let service: ClientplanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClientplanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
