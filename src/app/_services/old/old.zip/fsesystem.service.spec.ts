import { TestBed } from '@angular/core/testing';

import { FsesystemService } from './fsesystem.service';

describe('FsesystemService', () => {
  let service: FsesystemService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FsesystemService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
