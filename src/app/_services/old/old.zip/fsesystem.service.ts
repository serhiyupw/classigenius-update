import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DataService } from './data.service';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class FsesystemService extends DataService {
  constructor(http: HttpClient) {
    super('http://80.241.219.201:8080/InvoiceCloudServer/Api/fsesystem', http);
  }
}

