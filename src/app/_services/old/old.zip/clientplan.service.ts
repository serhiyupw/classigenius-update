import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import { HttpClient } from '@angular/common/http';

@Injectable(
  {
    providedIn: 'root'
  }
)

export class ClientplanService extends DataService {

  constructor(http: HttpClient) {
    super('http://80.241.219.201:8080/InvoiceCloudServer/Api/clientplan', http);
  }

}